from flask import Flask, render_template, request, abort, Response

app = Flask(__name__)

# Hardcoded credentials for demonstration
USERNAME = "jingwen.hu"
PASSWORD = "lolzed"

# Function to check credentials
def check_credentials(username, password):
    return username == USERNAME and password == PASSWORD

# Function to read websites from a text file
def read_websites():
    websites = []
    try:
        with open('websites.txt', 'r') as file:
            for line in file:
                name, url = line.strip().split('-')
                websites.append({'name': name, 'url': url})
    except FileNotFoundError:
        print("The file 'websites.txt' was not found.")
    return websites

@app.route('/')
def index():
    auth = request.authorization
    if not auth or not check_credentials(auth.username, auth.password):
        # Create a response object
        response = Response(render_template('error.html'), status=401)
        response.headers['WWW-Authenticate'] = 'Basic realm="Login Required"'
        return response

    websites = read_websites()
    return render_template('index.html', websites=websites)

if __name__ == '__main__':
    app.run(debug=True, port=5988)
