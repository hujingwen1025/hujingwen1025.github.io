from flask import Flask, request, render_template_string, render_template, redirect, url_for, session, flash, send_from_directory, jsonify
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)
PASSWORD = 'supersecretpassword'            # Change this to your desired password
BULLETIN_PATH = os.path.join(os.path.dirname(__file__), 'bulletin')
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
PICTURES_PATH = os.path.join(os.path.dirname(__file__), 'pictures')
DUTY_TEACHERS_PATH = os.path.join(os.path.dirname(__file__), 'duty_teachers')
AOD_TEACHERS_PATH = os.path.join(os.path.dirname(__file__), 'aod_teachers')
COUNTDOWN_PATH = os.path.join(os.path.dirname(__file__), 'countdown_events')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def root():
    return redirect('/edit')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form.get('password') == PASSWORD:
            session['logged_in'] = True
            return redirect(url_for('edit'))
        else:
            error = 'Incorrect password.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/edit', methods=['GET', 'POST'])
@login_required
def edit():
    msg = None
    if request.method == 'POST':
        content = request.form.get('content', '')
        with open(BULLETIN_PATH, 'w', encoding='utf-8') as f:
            f.write(content.strip() + '\n')
        msg = "Saved successfully."
    if os.path.exists(BULLETIN_PATH):
        with open(BULLETIN_PATH, 'r', encoding='utf-8') as f:
            content = f.read()
    else:
        content = ''
    return render_template('edit.html', content=content, msg=msg)

@app.route('/display')
def display():
    return render_template('display.html')

@app.route('/bulletin')
def get_text_file():
    try:
        with open('bulletin', 'r') as f:
            content = f.read()
        return content, 200, {'Content-Type': 'text/plain'}
    except FileNotFoundError:
        return "File not found", 404

@app.route('/manage_pictures', methods=['GET', 'POST'])
@login_required
def manage_pictures():
    msg = None
    error = None
    # Load current pictures list
    pictures = []
    if os.path.exists(PICTURES_PATH):
        with open(PICTURES_PATH, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f if line.strip()]
        for i in range(0, len(lines), 2):
            path = lines[i]
            caption = lines[i+1] if i+1 < len(lines) else ''
            pictures.append({'path': path, 'caption': caption})
    # Handle upload
    if request.method == 'POST':
        if 'upload' in request.form:
            file = request.files.get('file')
            caption = request.form.get('caption', '')
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                save_path = os.path.join(UPLOAD_FOLDER, filename)
                file.save(save_path)
                rel_path = f"/static/uploads/{filename}"
                # Append to pictures file
                with open(PICTURES_PATH, 'a', encoding='utf-8') as f:
                    f.write(rel_path + '\n')
                    f.write(caption.strip() + '\n')
                msg = "Image uploaded."
                return redirect(url_for('manage_pictures'))
            else:
                error = "Invalid file."
        elif 'delete' in request.form:
            idx = int(request.form.get('delete'))
            # Remove from pictures list and file
            if 0 <= idx < len(pictures):
                img_path = pictures[idx]['path']
                # Remove file from disk if exists and is in uploads
                if img_path.startswith('/static/uploads/'):
                    try:
                        os.remove(os.path.join(os.path.dirname(__file__), img_path.lstrip('/')))
                    except Exception:
                        pass
                # Remove from pictures file
                new_lines = []
                for i, pic in enumerate(pictures):
                    if i != idx:
                        new_lines.append(pic['path'])
                        new_lines.append(pic['caption'])
                with open(PICTURES_PATH, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(new_lines) + '\n')
                msg = "Image removed."
                return redirect(url_for('manage_pictures'))
    return render_template('manage_pictures.html', pictures=pictures, msg=msg, error=error)

@app.route('/pictures', methods=['GET'])
def get_pictures():
    if os.path.exists(PICTURES_PATH):
        with open(PICTURES_PATH, 'r', encoding='utf-8') as f:
            return f.read(), 200, {'Content-Type': 'text/plain'}
    return "", 200, {'Content-Type': 'text/plain'}

@app.route('/edit_duty_teachers', methods=['GET', 'POST'])
@login_required
def edit_duty_teachers():
    msg = None
    teachers = [""] * 5
    aod_teachers = [""] * 5
    if os.path.exists(DUTY_TEACHERS_PATH):
        with open(DUTY_TEACHERS_PATH, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines()]
            for i in range(min(5, len(lines))):
                teachers[i] = lines[i]
    if os.path.exists(AOD_TEACHERS_PATH):
        with open(AOD_TEACHERS_PATH, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines()]
            for i in range(min(5, len(lines))):
                aod_teachers[i] = lines[i]
    if request.method == 'POST':
        teachers = [
            request.form.get(f'teacher{i+1}', '').strip()
            for i in range(5)
        ]
        aod_teachers = [
            request.form.get(f'aod_teacher{i+1}', '').strip()
            for i in range(5)
        ]
        with open(DUTY_TEACHERS_PATH, 'w', encoding='utf-8') as f:
            for t in teachers:
                f.write(t + '\n')
        with open(AOD_TEACHERS_PATH, 'w', encoding='utf-8') as f:
            for t in aod_teachers:
                f.write(t + '\n')
        msg = "Duty and AOD teachers updated."
    return render_template('edit_duty_teachers.html', teachers=teachers, aod_teachers=aod_teachers, msg=msg)

@app.route('/duty_teachers')
def get_duty_teachers():
    if os.path.exists(DUTY_TEACHERS_PATH):
        with open(DUTY_TEACHERS_PATH, 'r', encoding='utf-8') as f:
            return f.read(), 200, {'Content-Type': 'text/plain'}
    return "", 200, {'Content-Type': 'text/plain'}

@app.route('/aod_teachers')
def get_aod_teachers():
    if os.path.exists(AOD_TEACHERS_PATH):
        with open(AOD_TEACHERS_PATH, 'r', encoding='utf-8') as f:
            return f.read(), 200, {'Content-Type': 'text/plain'}
    return "", 200, {'Content-Type': 'text/plain'}

@app.route('/edit_countdown', methods=['GET', 'POST'])
@login_required
def edit_countdown():
    msg = None
    events = []
    # Load existing events
    if os.path.exists(COUNTDOWN_PATH):
        with open(COUNTDOWN_PATH, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines()]
            for i in range(0, len(lines), 2):
                if i+1 < len(lines):
                    events.append({'event_name': lines[i], 'event_date': lines[i+1]})
    if request.method == 'POST':
        # Gather all event_name and event_date pairs from the form
        events = []
        idx = 0
        while True:
            name = request.form.get(f'event_name_{idx}', '').strip()
            date = request.form.get(f'event_date_{idx}', '').strip()
            if not name and not date:
                break
            if name and date:
                events.append({'event_name': name, 'event_date': date})
            idx += 1
        # Save to file
        with open(COUNTDOWN_PATH, 'w', encoding='utf-8') as f:
            for event in events:
                f.write(event['event_name'] + '\n')
                f.write(event['event_date'] + '\n')
        msg = "Countdown events updated."
    return render_template('edit_countdown.html', events=events, msg=msg)

@app.route('/countdown_event')
def get_countdown_event():
    events = []
    if os.path.exists(COUNTDOWN_PATH):
        with open(COUNTDOWN_PATH, 'r', encoding='utf-8') as f:
            lines = [line.strip() for line in f.readlines()]
            for i in range(0, len(lines), 2):
                if i+1 < len(lines):
                    events.append({'event_name': lines[i], 'event_date': lines[i+1]})
    return jsonify(events)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
